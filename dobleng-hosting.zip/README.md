# Dobleng Hosting - Full Deploy Guide

1. Clone the repo to your server
2. Set up Docker and Docker Compose
3. Edit the .env file with your credentials
4. Run the following command to start the containers:
   docker-compose up -d --build
5. Access the frontend at http://localhost:8080
6. Backend API will be available at http://localhost:3000/api
